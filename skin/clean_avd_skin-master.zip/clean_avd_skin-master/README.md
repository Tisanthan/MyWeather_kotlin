How to use a clean Android Emulator Skin:

